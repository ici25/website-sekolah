<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "anta_thadore";

// Membuat koneksi menggunakan mysqli
$koneksi = mysqli_connect($host, $user, $pass, $db);

// Periksa apakah koneksi berhasil
if (!$koneksi) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}
?>