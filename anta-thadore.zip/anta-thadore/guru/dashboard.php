<?php
session_start();

// Cek sesi login guru
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'guru') {
    header("Location: ../login.php");
    exit;
}

$nama_lengkap = $_SESSION['nama_lengkap'] ?? 'Nama Guru, S.Pd.';

// Inisial untuk Avatar Profil
$words = explode(" ", $nama_lengkap);
$initials = "";
if (count($words) >= 2) {
    $initials = strtoupper(substr($words[0], 0, 1) . substr($words[1], 0, 1));
} else {
    $initials = strtoupper(substr($nama_lengkap, 0, 2));
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal Guru | ANTA THADORE</title>

    <!-- Google Fonts & FontAwesome -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --sidebar-bg: #0a3e31;
            --sidebar-hover: #0d4d3d;
            --sidebar-active: #135847;
            --main-bg: #f8f8f2;
            --card-bg: #ffffff;
            --lime-accent: #c0ed38;
            --lime-soft: #e8f7ad;
            --text-dark: #111827;
            --text-muted: #6b7280;
            --border-light: #e5e7eb;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        body {
            background-color: var(--main-bg);
            color: var(--text-dark);
            min-height: 100vh;
            display: flex;
        }

        /* --- SIDEBAR KIRI --- */
        .sidebar {
            width: 260px;
            background-color: var(--sidebar-bg);
            color: #ffffff;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 24px 16px;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
        }

        .brand-box {
            display: flex;
            align-items: center;
            gap: 12px;
            padding-bottom: 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .brand-logo {
            background-color: var(--lime-accent);
            color: var(--sidebar-bg);
            font-weight: 800;
            font-size: 14px;
            padding: 8px 10px;
            border-radius: 10px;
        }

        .brand-text strong {
            display: block;
            font-size: 15px;
            font-weight: 800;
            line-height: 1.2;
        }

        .brand-text span {
            font-size: 11px;
            color: rgba(255, 255, 255, 0.6);
        }

        .menu-label {
            font-size: 10.5px;
            font-weight: 800;
            letter-spacing: 1.5px;
            color: rgba(255, 255, 255, 0.4);
            margin: 24px 0 12px 12px;
        }

        .nav-list {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: rgba(255, 255, 255, 0.75);
            text-decoration: none;
            font-size: 13.5px;
            font-weight: 600;
            border-radius: 12px;
            transition: all 0.2s ease;
        }

        .nav-link:hover {
            background-color: var(--sidebar-hover);
            color: #ffffff;
        }

        .nav-link.active {
            background-color: var(--sidebar-active);
            color: #ffffff;
            font-weight: 700;
        }

        .nav-link i {
            font-size: 15px;
            width: 20px;
            text-align: center;
        }

        .sidebar-bottom {
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .btn-logout {
            color: rgba(255, 255, 255, 0.65);
            text-decoration: none;
            font-size: 13px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 12px;
            border-radius: 10px;
            transition: all 0.2s;
        }

        .btn-logout:hover {
            color: #ff8b8b;
            background-color: rgba(255, 255, 255, 0.05);
        }

        /* --- KONTEN UTAMA (KANAN) --- */
        .main-wrapper {
            margin-left: 260px;
            flex: 1;
            padding: 36px 48px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .top-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 28px;
        }

        .portal-tag {
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 1.5px;
            color: var(--sidebar-bg);
            text-transform: uppercase;
            margin-bottom: 4px;
        }

        .welcome-title {
            font-size: 32px;
            font-weight: 800;
            color: var(--sidebar-bg);
        }

        .profile-badge {
            display: flex;
            align-items: center;
            gap: 10px;
            background-color: var(--card-bg);
            padding: 6px 16px 6px 6px;
            border-radius: 30px;
            border: 1px solid var(--border-light);
            text-decoration: none;
            color: var(--text-dark);
            font-size: 13.5px;
            font-weight: 700;
            box-shadow: 0 2px 6px rgba(0,0,0,0.02);
            transition: all 0.2s;
        }

        .profile-badge:hover {
            border-color: var(--sidebar-bg);
        }

        .avatar-circle {
            width: 34px;
            height: 34px;
            background-color: var(--lime-accent);
            color: var(--sidebar-bg);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 800;
        }

        .hero-banner {
            background: linear-gradient(135deg, #0d4638 0%, #175d4c 100%);
            border-radius: 24px;
            padding: 36px 40px;
            color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
            box-shadow: 0 10px 25px rgba(10, 62, 49, 0.12);
        }

        .banner-content {
            max-width: 620px;
        }

        .year-badge {
            font-size: 10.5px;
            font-weight: 800;
            letter-spacing: 1.5px;
            color: var(--lime-accent);
            margin-bottom: 12px;
        }

        .banner-title {
            font-size: 26px;
            font-weight: 800;
            line-height: 1.3;
            margin-bottom: 12px;
        }

        .banner-desc {
            font-size: 13.5px;
            color: rgba(255, 255, 255, 0.75);
            line-height: 1.6;
        }

        .banner-icon-box {
            width: 64px;
            height: 64px;
            background-color: var(--lime-accent);
            color: var(--sidebar-bg);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 18px;
            margin-bottom: 24px;
        }

        .stat-card {
            background-color: var(--card-bg);
            border-radius: 20px;
            padding: 22px;
            border: 1px solid var(--border-light);
            text-decoration: none;
            color: var(--text-dark);
            transition: all 0.2s ease;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            border-color: var(--sidebar-bg);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.05);
        }

        .stat-icon {
            width: 38px;
            height: 38px;
            background-color: #f1f7f4;
            color: var(--sidebar-bg);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 15px;
            margin-bottom: 16px;
        }

        .stat-label {
            font-size: 12.5px;
            color: var(--text-muted);
            margin-bottom: 6px;
            font-weight: 500;
        }

        .stat-number {
            font-size: 28px;
            font-weight: 800;
            color: var(--sidebar-bg);
            margin-bottom: 12px;
        }

        .stat-footer {
            font-size: 11.5px;
            font-weight: 800;
            color: var(--sidebar-bg);
        }

        .bottom-grid {
            display: grid;
            grid-template-columns: 1.15fr 0.85fr;
            gap: 20px;
        }

        .section-card {
            background-color: var(--card-bg);
            border-radius: 24px;
            padding: 28px;
            border: 1px solid var(--border-light);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02);
        }

        .section-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .section-tag {
            font-size: 10.5px;
            font-weight: 800;
            letter-spacing: 1.5px;
            color: var(--sidebar-bg);
            text-transform: uppercase;
            margin-bottom: 4px;
        }

        .section-title {
            font-size: 22px;
            font-weight: 800;
            color: var(--sidebar-bg);
        }

        .header-icon-btn {
            width: 38px;
            height: 38px;
            background-color: #edf7eb;
            color: var(--sidebar-bg);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }

        .action-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .action-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 14px 18px;
            border: 1px solid var(--border-light);
            border-radius: 16px;
            text-decoration: none;
            color: var(--text-dark);
            transition: all 0.2s ease;
        }

        .action-item:hover {
            border-color: var(--sidebar-bg);
            background-color: #fafdfb;
            transform: translateX(4px);
        }

        .action-left {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .action-icon {
            width: 42px;
            height: 42px;
            background-color: var(--lime-accent);
            color: var(--sidebar-bg);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
        }

        .action-info h4 {
            font-size: 14.5px;
            font-weight: 800;
            color: var(--sidebar-bg);
            margin-bottom: 2px;
        }

        .action-info p {
            font-size: 12px;
            color: var(--text-muted);
        }

        .action-arrow {
            color: var(--sidebar-bg);
            font-size: 14px;
        }

        .notes-list {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 16px;
            margin-top: 10px;
        }

        .notes-list li {
            position: relative;
            padding-left: 20px;
            font-size: 13.5px;
            color: var(--text-muted);
            line-height: 1.6;
        }

        .notes-list li::before {
            content: "•";
            color: var(--sidebar-bg);
            font-weight: bold;
            font-size: 18px;
            position: absolute;
            left: 0;
            top: -2px;
        }

        .footer-text {
            text-align: center;
            font-size: 12px;
            color: var(--text-muted);
            margin-top: 36px;
            padding-top: 20px;
            border-top: 1px dashed var(--border-light);
        }

        @media (max-width: 1024px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .bottom-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

    <!-- SIDEBAR KIRI -->
    <aside class="sidebar">
        <div>
            <div class="brand-box">
                <div class="brand-logo">AT</div>
                <div class="brand-text">
                    <strong>ANTA THADORE</strong>
                    <span>Portal Guru</span>
                </div>
            </div>

            <div class="menu-label">MENU UTAMA</div>

            <ul class="nav-list">
                <li>
                    <a href="dashboard.php" class="nav-link active">
                        <i class="fa-solid fa-compass"></i> Dashboard
                    </a>
                </li>
                <li>
                    <a href="kelola_jadwal.php" class="nav-link">
                        <i class="fa-solid fa-calendar-days"></i> Kelola Jadwal
                    </a>
                </li>
                <li>
                    <a href="profil.php" class="nav-link">
                        <i class="fa-solid fa-diamond"></i> Profil Guru
                    </a>
                </li>
                <li>
                    <a href="rencana.php" class="nav-link">
                        <i class="fa-solid fa-bars"></i> Rencana Pembelajaran
                    </a>
                </li>
                <li>
                    <a href="bank_soal.php" class="nav-link">
                        <i class="fa-solid fa-circle-question"></i> Bank Soal PDF
                    </a>
                </li>
                <li>
                    <a href="laporan.php" class="nav-link">
                        <i class="fa-solid fa-square-poll-vertical"></i> Laporan Kinerja
                    </a>
                </li>
                <!-- MENU BUKU DIGITAL BSE YANG DITAMBAHKAN -->
                <li>
                    <a href="bse.php" class="nav-link">
                        <i class="fa-solid fa-book-bookmark"></i> Buku Digital BSE
                    </a>
                </li>
                <li>
                    <a href="pendaftaran.php" class="nav-link">
                        <i class="fa-solid fa-file-shield"></i> Berkas Pendaftaran
                    </a>
                </li>
            </ul>
        </div>

        <div class="sidebar-bottom">
            <a href="../logout.php" class="btn-logout">
                <i class="fa-solid fa-arrow-left"></i> Kembali ke Halaman Awal
            </a>
        </div>
    </aside>

    <!-- KONTEN UTAMA (KANAN) -->
    <main class="main-wrapper">
        <div>
            <!-- Header Atas -->
            <div class="top-header">
                <div>
                    <div class="portal-tag">PORTAL GURU</div>
                    <h1 class="welcome-title">Selamat datang, <?= htmlspecialchars($nama_lengkap) ?></h1>
                </div>

                <a href="profil.php" class="profile-badge">
                    <div class="avatar-circle"><?= $initials ?></div>
                    <span>Profil</span>
                </a>
            </div>

            <!-- Banner Hero -->
            <div class="hero-banner">
                <div class="banner-content">
                    <div class="year-badge">TAHUN AJARAN 2026/2027</div>
                    <h2 class="banner-title">Kelola dokumen dan kinerja pembelajaran dalam satu portal.</h2>
                    <p class="banner-desc">Portal ini menampilkan rancangan tata kelola untuk guru. Anda dapat mengedit profil, mengatur rencana pembelajaran, serta mengunggah dokumen PDF dan buku digital.</p>
                </div>
                <div class="banner-icon-box">
                    <i class="fa-solid fa-sparkles"></i>
                </div>
            </div>

            <!-- Grid Kartu Statistik -->
            <div class="stats-grid">
                <a href="rencana.php" class="stat-card">
                    <div>
                        <div class="stat-icon"><i class="fa-solid fa-bars"></i></div>
                        <div class="stat-label">Rencana Pembelajaran</div>
                        <div class="stat-number">1</div>
                    </div>
                    <div class="stat-footer">Dokumen PDF</div>
                </a>

                <a href="bank_soal.php" class="stat-card">
                    <div>
                        <div class="stat-icon"><i class="fa-solid fa-circle-question"></i></div>
                        <div class="stat-label">Bank Soal</div>
                        <div class="stat-number">1</div>
                    </div>
                    <div class="stat-footer">Dokumen PDF</div>
                </a>

                <a href="bse.php" class="stat-card">
                    <div>
                        <div class="stat-icon"><i class="fa-solid fa-book-bookmark"></i></div>
                        <div class="stat-label">Buku Digital BSE</div>
                        <div class="stat-number">New</div>
                    </div>
                    <div class="stat-footer">Upload & Kelola</div>
                </a>

                <a href="profil.php" class="stat-card">
                    <div>
                        <div class="stat-icon"><i class="fa-solid fa-diamond"></i></div>
                        <div class="stat-label">Status Profil</div>
                        <div class="stat-number">Siap</div>
                    </div>
                    <div class="stat-footer">Data aktif</div>
                </a>
            </div>

            <!-- Bottom Grid: Akses Cepat & Catatan -->
            <div class="bottom-grid">
                <div class="section-card">
                    <div class="section-header">
                        <div>
                            <div class="section-tag">AKSES CEPAT</div>
                            <h3 class="section-title">Kelola dokumen</h3>
                        </div>
                        <div class="header-icon-btn">
                            <i class="fa-solid fa-arrow-right"></i>
                        </div>
                    </div>

                    <div class="action-list">
                        <!-- Akses Cepat ke Buku Digital BSE -->
                        <a href="bse.php" class="action-item">
                            <div class="action-left">
                                <div class="action-icon"><i class="fa-solid fa-book-bookmark"></i></div>
                                <div class="action-info">
                                    <h4>Buku Digital BSE</h4>
                                    <p>Unggah dan bagikan buku/modul ke siswa</p>
                                </div>
                            </div>
                            <i class="fa-solid fa-arrow-right action-arrow"></i>
                        </a>

                        <a href="profil.php" class="action-item">
                            <div class="action-left">
                                <div class="action-icon"><i class="fa-solid fa-diamond"></i></div>
                                <div class="action-info">
                                    <h4>Edit Profil Guru</h4>
                                    <p>Ubah biodata dan informasi mengajar</p>
                                </div>
                            </div>
                            <i class="fa-solid fa-arrow-right action-arrow"></i>
                        </a>

                        <a href="rencana.php" class="action-item">
                            <div class="action-left">
                                <div class="action-icon"><i class="fa-solid fa-bars"></i></div>
                                <div class="action-info">
                                    <h4>Tambah Rencana Pembelajaran</h4>
                                    <p>Unggah atau perbarui dokumen PDF</p>
                                </div>
                            </div>
                            <i class="fa-solid fa-arrow-right action-arrow"></i>
                        </a>

                        <a href="bank_soal.php" class="action-item">
                            <div class="action-left">
                                <div class="action-icon"><i class="fa-solid fa-circle-question"></i></div>
                                <div class="action-info">
                                    <h4>Tambah Bank Soal</h4>
                                    <p>Simpan kumpulan soal dalam PDF</p>
                                </div>
                            </div>
                            <i class="fa-solid fa-arrow-right action-arrow"></i>
                        </a>

                        <a href="pendaftaran.php" class="action-item">
                            <div class="action-left">
                                <div class="action-icon"><i class="fa-solid fa-file-shield"></i></div>
                                <div class="action-info">
                                    <h4>Berkas Pendaftaran</h4>
                                    <p>Arsip dokumen rahasia dengan sandi</p>
                                </div>
                            </div>
                            <i class="fa-solid fa-arrow-right action-arrow"></i>
                        </a>
                    </div>
                </div>

                <div class="section-card">
                    <div class="section-header">
                        <div>
                            <div class="section-tag">CATATAN</div>
                            <h3 class="section-title">Informasi Sistem</h3>
                        </div>
                        <div class="header-icon-btn">
                            <i class="fa-solid fa-info"></i>
                        </div>
                    </div>

                    <ul class="notes-list">
                        <li>Menu Buku Digital BSE sekarang sudah terintegrasi untuk guru mengunggah materi.</li>
                        <li>Menu Berkas Pendaftaran dilindungi dengan password khusus.</li>
                        <li>Pastikan database tabel buku_digital dan berkas_pendaftaran sudah dibuat.</li>
                        <li>Sistem berjalan stabil dan terintegrasi penuh.</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="footer-text">
            © 2026 ANTA THADORE · Portal Guru
        </div>
    </main>

</body>
</html>