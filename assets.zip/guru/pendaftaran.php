<?php
// Panggil koneksi asli dari luar folder guru
include '../koneksi.php';

// Menyesuaikan jika nama variabel koneksi di file koneksi.php Anda berbeda
if (!isset($koneksi)) {
    if (isset($conn)) { $koneksi = $conn; }
    elseif (isset($db)) { $koneksi = $db; }
    elseif (isset($connection)) { $koneksi = $connection; }
}

// Panggil auth.php (file ini sudah menangani session_start secara otomatis)
include '../includes/auth.php';

// Password khusus untuk membuka menu ini
$password_menu = "rahasia123"; 

// Proses Cek Password yang dimasukkan
if (isset($_POST['submit_password'])) {
    if ($_POST['akses_password'] === $password_menu) {
        $_SESSION['akses_pendaftaran_verified'] = true;
    } else {
        $error_password = "Password salah! Silakan coba lagi.";
    }
}

// Tombol Keluar / Kunci Akses Kembali
if (isset($_GET['lock'])) {
    unset($_SESSION['akses_pendaftaran_verified']);
    header("Location: pendaftaran.php");
    exit;
}

// Jika sudah terverifikasi, jalankan fungsi unduh, tambah, edit, hapus
if (isset($_SESSION['akses_pendaftaran_verified']) && $_SESSION['akses_pendaftaran_verified'] === true) {

    // Handle Download PDF secara Private
    if (isset($_GET['download'])) {
        $id = intval($_GET['download']);
        $query = mysqli_query($koneksi, "SELECT * FROM berkas_pendaftaran WHERE id = $id");
        $data = mysqli_fetch_assoc($query);
        if ($data) {
            $filepath = "../uploads/private/" . $data['file_pdf'];
            if (file_exists($filepath)) {
                header('Content-Description: File Transfer');
                header('Content-Type: application/pdf');
                header('Content-Disposition: attachment; filename="' . basename($data['nama_berkas'] . '.pdf') . '"');
                header('Expires: 0');
                header('Cache-Control: must-revalidate');
                header('Pragma: public');
                header('Content-Length: ' . filesize($filepath));
                readfile($filepath);
                exit;
            }
        }
        echo "<script>alert('File PDF tidak ditemukan!'); window.location='pendaftaran.php';</script>";
        exit;
    }

    // Handle Tambah & Edit Data Berkas
    if (isset($_POST['simpan'])) {
        $id = $_POST['id'] ?? '';
        $nama_berkas = mysqli_real_escape_string($koneksi, $_POST['nama_berkas']);
        $keterangan = mysqli_real_escape_string($koneksi, $_POST['keterangan']);
        
        $uploadDir = '../uploads/private/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        if (!empty($_FILES['file_pdf']['name'])) {
            $fileName = time() . '_' . basename($_FILES['file_pdf']['name']);
            $targetFilePath = $uploadDir . $fileName;
            $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

            if (strtolower($fileType) == 'pdf') {
                if (move_uploaded_file($_FILES['file_pdf']['tmp_name'], $targetFilePath)) {
                    if (!empty($id)) {
                        $old = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT file_pdf FROM berkas_pendaftaran WHERE id = $id"));
                        if ($old && file_exists($uploadDir . $old['file_pdf'])) {
                            unlink($uploadDir . $old['file_pdf']);
                        }
                        mysqli_query($koneksi, "UPDATE berkas_pendaftaran SET nama_berkas='$nama_berkas', keterangan='$keterangan', file_pdf='$fileName' WHERE id=$id");
                    } else {
                        mysqli_query($koneksi, "INSERT INTO berkas_pendaftaran (nama_berkas, keterangan, file_pdf) VALUES ('$nama_berkas', '$keterangan', '$fileName')");
                    }
                }
            }
        } else if (!empty($id)) {
            mysqli_query($koneksi, "UPDATE berkas_pendaftaran SET nama_berkas='$nama_berkas', keterangan='$keterangan' WHERE id=$id");
        }
        header("Location: pendaftaran.php");
        exit;
    }

    // Handle Hapus Data
    if (isset($_GET['hapus'])) {
        $id = intval($_GET['hapus']);
        $old = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT file_pdf FROM berkas_pendaftaran WHERE id = $id"));
        if ($old) {
            $filePath = '../uploads/private/' . $old['file_pdf'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
            mysqli_query($koneksi, "DELETE FROM berkas_pendaftaran WHERE id = $id");
        }
        header("Location: pendaftaran.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Berkas Pendaftaran | Portal Guru</title>

    <!-- Google Fonts & FontAwesome -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        :root {
            --sidebar-bg: #0a3e31;
            --sidebar-hover: #0d4d3d;
            --sidebar-active: #135847;
            --main-bg: #f8f8f2;
            --card-bg: #ffffff;
            --lime-accent: #c0ed38;
            --text-dark: #111827;
            --text-muted: #6b7280;
            --border-light: #e5e7eb;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        body {
            background-color: var(--main-bg);
            color: var(--text-dark);
            min-height: 100vh;
            display: flex;
        }

        /* --- SIDEBAR KIRI --- */
        .sidebar {
            width: 260px;
            background-color: var(--sidebar-bg);
            color: #ffffff;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 24px 16px;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
        }

        .brand-box {
            display: flex;
            align-items: center;
            gap: 12px;
            padding-bottom: 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .brand-logo {
            background-color: var(--lime-accent);
            color: var(--sidebar-bg);
            font-weight: 800;
            font-size: 14px;
            padding: 8px 10px;
            border-radius: 10px;
        }

        .brand-text strong {
            display: block;
            font-size: 15px;
            font-weight: 800;
            line-height: 1.2;
        }

        .brand-text span {
            font-size: 11px;
            color: rgba(255, 255, 255, 0.6);
        }

        .menu-label {
            font-size: 10.5px;
            font-weight: 800;
            letter-spacing: 1.5px;
            color: rgba(255, 255, 255, 0.4);
            margin: 24px 0 12px 12px;
        }

        .nav-list {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: rgba(255, 255, 255, 0.75);
            text-decoration: none;
            font-size: 13.5px;
            font-weight: 600;
            border-radius: 12px;
            transition: all 0.2s ease;
        }

        .nav-link:hover {
            background-color: var(--sidebar-hover);
            color: #ffffff;
        }

        .nav-link.active {
            background-color: var(--sidebar-active);
            color: #ffffff;
            font-weight: 700;
        }

        .nav-link i {
            font-size: 15px;
            width: 20px;
            text-align: center;
        }

        .sidebar-bottom {
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .btn-logout {
            color: rgba(255, 255, 255, 0.65);
            text-decoration: none;
            font-size: 13px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 12px;
            border-radius: 10px;
            transition: all 0.2s;
        }

        .btn-logout:hover {
            color: #ff8b8b;
            background-color: rgba(255, 255, 255, 0.05);
        }

        .main-wrapper {
            margin-left: 260px;
            flex: 1;
            padding: 36px 48px;
        }
    </style>
</head>
<body class="bg-gray-100">

    <!-- SIDEBAR KIRI -->
    <aside class="sidebar">
        <div>
            <div class="brand-box">
                <div class="brand-logo">AT</div>
                <div class="brand-text">
                    <strong>ANTA THADORE</strong>
                    <span>Portal Guru</span>
                </div>
            </div>

            <div class="menu-label">MENU UTAMA</div>

            <ul class="nav-list">
                <li>
                    <a href="dashboard.php" class="nav-link">
                        <i class="fa-solid fa-compass"></i> Dashboard
                    </a>
                </li>
                <li>
                    <a href="kelola_jadwal.php" class="nav-link">
                        <i class="fa-solid fa-calendar-days"></i> Kelola Jadwal
                    </a>
                </li>
                <li>
                    <a href="profil.php" class="nav-link">
                        <i class="fa-solid fa-diamond"></i> Profil Guru
                    </a>
                </li>
                <li>
                    <a href="rencana.php" class="nav-link">
                        <i class="fa-solid fa-bars"></i> Rencana Pembelajaran
                    </a>
                </li>
                <li>
                    <a href="bank_soal.php" class="nav-link">
                        <i class="fa-solid fa-circle-question"></i> Bank Soal PDF
                    </a>
                </li>
                <li>
                    <a href="laporan.php" class="nav-link">
                        <i class="fa-solid fa-square-poll-vertical"></i> Laporan Kinerja
                    </a>
                </li>
                <li>
                    <a href="pendaftaran.php" class="nav-link active">
                        <i class="fa-solid fa-file-shield"></i> Berkas Pendaftaran
                    </a>
                </li>
            </ul>
        </div>

        <div class="sidebar-bottom">
            <a href="../logout.php" class="btn-logout">
                <i class="fa-solid fa-arrow-left"></i> Kembali ke Halaman Awal
            </a>
        </div>
    </aside>

    <!-- KONTEN UTAMA -->
    <main class="main-wrapper">
        <h1 class="text-2xl font-bold mb-6 text-gray-800">Berkas Pendaftaran</h1>

        <?php if (!isset($_SESSION['akses_pendaftaran_verified']) || $_SESSION['akses_pendaftaran_verified'] !== true): ?>
            <!-- Tampilan Kotak Input Password -->
            <div class="bg-white p-8 rounded-lg shadow max-w-md mx-auto mt-20 border border-gray-200">
                <h2 class="text-xl font-bold mb-4 text-gray-800 text-center">Autentikasi Akses</h2>
                <p class="text-sm text-gray-600 mb-6 text-center">Masukkan password khusus untuk membuka menu Berkas Pendaftaran.</p>
                
                <?php if (isset($error_password)): ?>
                    <div class="bg-red-100 text-red-700 p-3 rounded mb-4 text-sm text-center"><?= $error_password ?></div>
                <?php endif; ?>

                <form action="pendaftaran.php" method="POST">
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Password Akses</label>
                        <input type="password" name="akses_password" required class="w-full border rounded-md p-2.5 border-gray-300 focus:outline-none focus:ring-2 focus:ring-emerald-600" placeholder="Masukkan password...">
                    </div>
                    <button type="submit" name="submit_password" class="w-full bg-emerald-600 text-white py-2.5 rounded-md hover:bg-emerald-700 font-semibold transition">Buka Akses</button>
                </form>
            </div>
        <?php else: ?>
            <!-- Konten Utama Jika Password Benar -->
            <div class="flex justify-between items-center mb-4">
                <span class="text-sm text-emerald-700 font-semibold bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">Akses Terverifikasi</span>
                <a href="pendaftaran.php?lock=true" class="text-sm text-red-600 hover:underline font-semibold">Kunci Kembali Menu</a>
            </div>

            <?php 
            $editData = null;
            if (isset($_GET['edit'])) {
                $idEdit = intval($_GET['edit']);
                $editData = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM berkas_pendaftaran WHERE id = $idEdit"));
            }
            ?>
            <div class="bg-white p-6 rounded-lg shadow mb-6">
                <h2 class="text-lg font-semibold mb-4"><?= $editData ? 'Edit Berkas PDF' : 'Unggah Berkas PDF Baru' ?></h2>
                <form action="pendaftaran.php" method="POST" enctype="multipart/form-data" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input type="hidden" name="id" value="<?= $editData['id'] ?? '' ?>">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Nama Berkas</label>
                        <input type="text" name="nama_berkas" value="<?= htmlspecialchars($editData['nama_berkas'] ?? '') ?>" required class="mt-1 block w-full border rounded-md p-2 border-gray-300">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">File PDF <?= $editData ? '(Biarkan kosong jika tidak diubah)' : '' ?></label>
                        <input type="file" name="file_pdf" accept=".pdf" <?= $editData ? '' : 'required' ?> class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100">
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700">Keterangan</label>
                        <textarea name="keterangan" rows="2" class="mt-1 block w-full border rounded-md p-2 border-gray-300"><?= htmlspecialchars($editData['keterangan'] ?? '') ?></textarea>
                    </div>
                    <div class="md:col-span-2 flex gap-2">
                        <button type="submit" name="simpan" class="bg-emerald-600 text-white px-4 py-2 rounded-md hover:bg-emerald-700">Simpan Berkas</button>
                        <?php if ($editData): ?>
                            <a href="pendaftaran.php" class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600">Batal</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <!-- Table Data Berkas yang Telah Dimasukkan -->
            <div class="bg-white rounded-lg shadow overflow-hidden">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">No</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nama Berkas</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Keterangan</th>
                            <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php 
                        $no = 1;
                        $result = mysqli_query($koneksi, "SELECT * FROM berkas_pendaftaran ORDER BY id DESC");
                        if ($result && mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)): 
                        ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?= $no++ ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?= htmlspecialchars($row['nama_berkas']) ?></td>
                            <td class="px-6 py-4 text-sm text-gray-500"><?= htmlspecialchars($row['keterangan']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-center text-sm font-medium space-x-2">
                                <a href="pendaftaran.php?download=<?= $row['id'] ?>" class="text-blue-600 hover:text-blue-900 font-semibold">Unduh</a>
                                <a href="pendaftaran.php?edit=<?= $row['id'] ?>" class="text-amber-600 hover:text-amber-900 font-semibold">Ubah</a>
                                <a href="pendaftaran.php?hapus=<?= $row['id'] ?>" onclick="return confirm('Yakin ingin menghapus berkas ini?')" class="text-red-600 hover:text-red-900 font-semibold">Hapus</a>
                            </td>
                        </tr>
                        <?php 
                            endwhile; 
                        } else {
                        ?>
                        <tr>
                            <td colspan="4" class="px-6 py-4 text-center text-sm text-gray-500">Belum ada berkas PDF yang dimasukkan.</td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </main>

</body>
</html>