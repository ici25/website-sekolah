<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'guru') {
    header("Location: ../login.php");
    exit;
}

$nama_lengkap = $_SESSION['nama_lengkap'] ?? 'Nama Guru, S.Pd.';
$words = explode(" ", $nama_lengkap);
$initials = (count($words) >= 2) ? strtoupper(substr($words[0], 0, 1) . substr($words[1], 0, 1)) : strtoupper(substr($nama_lengkap, 0, 2));

$success_msg = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $success_msg = "Dokumen Bank Soal berhasil diunggah!";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bank Soal PDF | ANTA THADORE</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --sidebar-bg: #0a3e31;
            --sidebar-hover: #0d4d3d;
            --sidebar-active: #135847;
            --main-bg: #f8f8f2;
            --card-bg: #ffffff;
            --lime-accent: #c0ed38;
            --text-dark: #111827;
            --text-muted: #6b7280;
            --border-light: #e5e7eb;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Plus Jakarta Sans', sans-serif; }
        body { background-color: var(--main-bg); color: var(--text-dark); min-height: 100vh; display: flex; }

        .sidebar {
            width: 260px; background-color: var(--sidebar-bg); color: #ffffff;
            display: flex; flex-direction: column; justify-content: space-between;
            padding: 24px 16px; position: fixed; top: 0; bottom: 0; left: 0; z-index: 100;
        }
        .brand-box { display: flex; align-items: center; gap: 12px; padding-bottom: 24px; border-bottom: 1px solid rgba(255, 255, 255, 0.1); }
        .brand-logo { background-color: var(--lime-accent); color: var(--sidebar-bg); font-weight: 800; font-size: 14px; padding: 8px 10px; border-radius: 10px; }
        .brand-text strong { display: block; font-size: 15px; font-weight: 800; line-height: 1.2; }
        .brand-text span { font-size: 11px; color: rgba(255, 255, 255, 0.6); }
        .menu-label { font-size: 10.5px; font-weight: 800; letter-spacing: 1.5px; color: rgba(255, 255, 255, 0.4); margin: 24px 0 12px 12px; }
        .nav-list { list-style: none; display: flex; flex-direction: column; gap: 4px; }
        .nav-link { display: flex; align-items: center; gap: 12px; padding: 12px 16px; color: rgba(255, 255, 255, 0.75); text-decoration: none; font-size: 13.5px; font-weight: 600; border-radius: 12px; transition: all 0.2s ease; }
        .nav-link:hover { background-color: var(--sidebar-hover); color: #ffffff; }
        .nav-link.active { background-color: var(--sidebar-active); color: #ffffff; font-weight: 700; }
        .nav-link i { font-size: 15px; width: 20px; text-align: center; }
        .sidebar-bottom { padding-top: 20px; border-top: 1px solid rgba(255, 255, 255, 0.1); }
        .btn-logout { color: rgba(255, 255, 255, 0.65); text-decoration: none; font-size: 13px; font-weight: 600; display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 10px; transition: all 0.2s; }
        .btn-logout:hover { color: #ff8b8b; background-color: rgba(255, 255, 255, 0.05); }

        .main-wrapper { margin-left: 260px; flex: 1; padding: 36px 48px; display: flex; flex-direction: column; justify-content: space-between; }
        .top-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 28px; }
        .portal-tag { font-size: 11px; font-weight: 800; letter-spacing: 1.5px; color: var(--sidebar-bg); text-transform: uppercase; margin-bottom: 4px; }
        .welcome-title { font-size: 32px; font-weight: 800; color: var(--sidebar-bg); }
        .profile-badge { display: flex; align-items: center; gap: 10px; background-color: var(--card-bg); padding: 6px 16px 6px 6px; border-radius: 30px; border: 1px solid var(--border-light); text-decoration: none; color: var(--text-dark); font-size: 13.5px; font-weight: 700; }
        .avatar-circle { width: 34px; height: 34px; background-color: var(--lime-accent); color: var(--sidebar-bg); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 800; }

        .content-card { background-color: var(--card-bg); border-radius: 24px; padding: 32px; border: 1px solid var(--border-light); box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02); margin-bottom: 24px; }
        .card-header-title { font-size: 20px; font-weight: 800; color: var(--sidebar-bg); margin-bottom: 4px; }
        .card-header-sub { font-size: 13px; color: var(--text-muted); margin-bottom: 20px; }
        .alert-success { background-color: #dcfce7; color: #166534; padding: 12px 16px; border-radius: 12px; font-size: 13px; font-weight: 700; margin-bottom: 20px; display: flex; align-items: center; gap: 8px; }

        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 13px; font-weight: 800; color: var(--text-dark); margin-bottom: 8px; }
        .form-control { width: 100%; padding: 12px 16px; border: 1px solid var(--border-light); border-radius: 12px; font-size: 13.5px; outline: none; background-color: #fcfdfe; }
        .btn-submit { background-color: var(--sidebar-bg); color: #ffffff; border: none; padding: 12px 24px; border-radius: 12px; font-size: 13.5px; font-weight: 800; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; }

        .doc-list { list-style: none; display: flex; flex-direction: column; gap: 12px; }
        .doc-item { display: flex; align-items: center; justify-content: space-between; padding: 16px; border: 1px solid var(--border-light); border-radius: 16px; background-color: #fafcfb; }
        .doc-info { display: flex; align-items: center; gap: 14px; }
        .doc-icon { width: 40px; height: 40px; background-color: #fef3c7; color: #d97706; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 18px; }
        .doc-text h4 { font-size: 14px; font-weight: 800; color: var(--sidebar-bg); }
        .doc-text p { font-size: 12px; color: var(--text-muted); }
        .btn-view { color: var(--sidebar-bg); text-decoration: none; font-size: 13px; font-weight: 800; display: flex; align-items: center; gap: 6px; background: var(--main-bg); padding: 8px 14px; border-radius: 10px; }

        .footer-text { text-align: center; font-size: 12px; color: var(--text-muted); margin-top: 20px; padding-top: 20px; border-top: 1px dashed var(--border-light); }
    </style>
</head>
<body>

    <aside class="sidebar">
        <div>
            <div class="brand-box">
                <div class="brand-logo">AT</div>
                <div class="brand-text">
                    <strong>ANTA THADORE</strong>
                    <span>Portal Guru</span>
                </div>
            </div>
            <div class="menu-label">MENU UTAMA</div>
            <ul class="nav-list">
                <li><a href="dashboard.php" class="nav-link"><i class="fa-solid fa-compass"></i> Dashboard</a></li>
                <li><a href="profil.php" class="nav-link"><i class="fa-solid fa-diamond"></i> Profil Guru</a></li>
                <li><a href="rencana.php" class="nav-link"><i class="fa-solid fa-bars"></i> Rencana Pembelajaran</a></li>
                <li><a href="bank_soal.php" class="nav-link active"><i class="fa-solid fa-circle-question"></i> Bank Soal PDF</a></li>
                <li><a href="laporan.php" class="nav-link"><i class="fa-solid fa-square-poll-vertical"></i> Laporan Kinerja</a></li>
            </ul>
        </div>
        <div class="sidebar-bottom">
            <a href="../login.php" class="btn-logout"><i class="fa-solid fa-arrow-left"></i> Kembali ke Halaman Awal</a>
        </div>
    </aside>

    <main class="main-wrapper">
        <div>
            <div class="top-header">
                <div>
                    <div class="portal-tag">ARSIP UJIAN</div>
                    <h1 class="welcome-title">Bank Soal PDF</h1>
                </div>
                <a href="profil.php" class="profile-badge">
                    <div class="avatar-circle"><?= $initials ?></div>
                    <span>Profil</span>
                </a>
            </div>

            <div class="content-card">
                <h2 class="card-header-title">Tambah Kumpulan Soal PDF</h2>
                <p class="card-header-sub">Simpan berkas soal ujian, kuis, atau latihan untuk dokumentasi evaluasi belajar.</p>

                <?php if ($success_msg !== ""): ?>
                    <div class="alert-success"><i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($success_msg) ?></div>
                <?php endif; ?>

                <form method="post" action="" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="keterangan">Keterangan / Nama Ujian</label>
                        <input type="text" id="keterangan" name="keterangan" class="form-control" placeholder="Contoh: Soal Ujian Tengah Semester Informatika Kelas X" required>
                    </div>
                    <div class="form-group">
                        <label for="file_soal">File Soal (Format PDF)</label>
                        <input type="file" id="file_soal" name="file_soal" class="form-control" accept=".pdf" required>
                    </div>
                    <button type="submit" class="btn-submit"><i class="fa-solid fa-file-arrow-up"></i> Unggah Bank Soal</button>
                </form>
            </div>

            <div class="content-card">
                <h2 class="card-header-title">Daftar Berkas Soal</h2>
                <p class="card-header-sub">Kumpulan bank soal ujian yang tersimpan.</p>

                <ul class="doc-list">
                    <li class="doc-item">
                        <div class="doc-info">
                            <div class="doc-icon"><i class="fa-solid fa-file-circle-question"></i></div>
                            <div class="doc-text">
                                <h4>Soal_UTS_Informatika_2026.pdf</h4>
                                <p>Diunggah pada: 2026-08-20 · Ukuran: 850 KB</p>
                            </div>
                        </div>
                        <a href="#" class="btn-view"><i class="fa-solid fa-eye"></i> Lihat PDF</a>
                    </li>
                </ul>
            </div>
        </div>

        <div class="footer-text">© 2026 ANTA THADORE · Portal Guru Frontend</div>
    </main>

</body>
</html>