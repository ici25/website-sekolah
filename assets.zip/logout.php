<?php
session_start();
$_SESSION = array();
session_destroy();

// Gunakan path absolut otomatis berdasarkan server agar tidak pernah salah jalur
$base_url = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
// Karena logout.php di root, arahkan langsung ke login.php
header("Location: login.php"); 
exit;
?>